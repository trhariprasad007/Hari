@echo off
echo =======================================================================
echo   SRM INSTITUTE OF SCIENCE AND TECHNOLOGY - TIRUCHIRAPPALLI
echo      CLA-2: ALGORITHM BATTLE - WHICH DATA STRUCTURE WINS?
echo =======================================================================
echo.
echo [1/2] Compiling Java source files...
javac src\*.java
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Compilation failed! Ensure JDK 11+ is installed.
    pause
    exit /b %ERRORLEVEL%
)
echo [SUCCESS] Compilation completed without errors.
echo.
echo [2/2] Running Main Interactive Defense Application...
java -cp . src.Main
pause
