package src;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Mini-Experiment Benchmark Runner
 * Executes controlled experimental tests on BST, AVL Tree, and Hashing
 * using the exact same dataset of 40 SRM IST student records.
 */
public class StudentBenchmark {

    public static class ExperimentReport {
        public int datasetSize;
        public int bstHeight;
        public int avlHeight;
        public int avlRotations;
        public int avlLL, avlRR, avlLR, avlRL;
        public int hashCapacity;
        public int hashCollisions;
        public double hashLoadFactor;

        public long bstInsertComps;
        public long avlInsertComps;
        public long hashInsertComps;

        // Successful searches
        public int bstSuccessMinComps = Integer.MAX_VALUE, bstSuccessMaxComps = 0;
        public double bstSuccessAvgComps = 0.0;
        public int avlSuccessMinComps = Integer.MAX_VALUE, avlSuccessMaxComps = 0;
        public double avlSuccessAvgComps = 0.0;
        public int hashSuccessMinComps = Integer.MAX_VALUE, hashSuccessMaxComps = 0;
        public double hashSuccessAvgComps = 0.0;

        // Unsuccessful searches
        public int bstFailMinComps = Integer.MAX_VALUE, bstFailMaxComps = 0;
        public double bstFailAvgComps = 0.0;
        public int avlFailMinComps = Integer.MAX_VALUE, avlFailMaxComps = 0;
        public double avlFailAvgComps = 0.0;
        public int hashFailMinComps = Integer.MAX_VALUE, hashFailMaxComps = 0;
        public double hashFailAvgComps = 0.0;
    }

    public static List<Student> loadDataset(String csvPath) {
        List<Student> list = new ArrayList<>();
        File file = new File(csvPath);
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line = br.readLine(); // Header
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    String[] parts = line.split(",");
                    if (parts.length >= 5) {
                        int reg = Integer.parseInt(parts[0].trim());
                        String name = parts[1].trim();
                        String dept = parts[2].trim();
                        double cgpa = Double.parseDouble(parts[3].trim());
                        String email = parts[4].trim();
                        list.add(new Student(reg, name, dept, cgpa, email));
                    }
                }
            } catch (IOException e) {
                System.err.println("Notice: Could not read CSV file: " + e.getMessage() + ". Using embedded dataset.");
            }
        }

        if (list.isEmpty()) {
            list = getFallbackDataset();
        }
        return list;
    }

    public static List<Student> getFallbackDataset() {
        List<Student> list = new ArrayList<>();
        int[] regs = {
            101, 205, 302, 408, 105, 201, 308, 403, 102, 208,
            304, 407, 107, 203, 306, 401, 109, 207, 301, 405,
            103, 209, 307, 409, 106, 202, 305, 402, 108, 204,
            303, 404, 104, 206, 310, 406, 110, 210, 309, 410
        };
        String[] names = {
            "Aarav Sharma", "Diya Patel", "Rohan Verma", "Karthik Subramanian", "Ananya Iyer",
            "Vikramaditya Rao", "Sneha Kulkarni", "Harish Raghu", "Meera Nambiar", "Arjun Reddy",
            "Pooja Hegde", "Ranbir Kapoor", "Siddharth Sen", "Kavya Krishnan", "Varun Teja",
            "Rahul Nair", "Ishaan Joshi", "Naveen Kumar", "Tanvi Deshmukh", "Sanjay Dutt",
            "Divya Spandana", "Ayushmann Khurrana", "Shreya Ghoshal", "Tarun Tahiliani", "Priyanka Das",
            "Gautam Gambhir", "Ritu Singhal", "Abhishek Bachchan", "Swati Mishra", "Manish Pandey",
            "Katrina Kaif", "Kunal Kapoor", "Alia Bhatt", "Shahid Kapoor", "Nandini Sundar",
            "Vicky Kaushal", "Deepika Padukone", "Bhavana Menon", "Aditi Ghosh", "Tara Sutaria"
        };
        String[] depts = {
            "CSE", "ECE", "IT", "MECH", "CSE", "ECE", "IT", "MECH", "CSE", "ECE",
            "IT", "MECH", "CSE", "ECE", "IT", "MECH", "CSE", "ECE", "IT", "MECH",
            "CSE", "ECE", "IT", "MECH", "CSE", "ECE", "IT", "MECH", "CSE", "ECE",
            "IT", "MECH", "CSE", "ECE", "IT", "MECH", "CSE", "ECE", "IT", "MECH"
        };
        double[] cgpas = {
            8.92, 9.15, 7.84, 7.60, 9.40, 8.12, 8.75, 7.45, 9.05, 8.45,
            8.80, 7.55, 7.95, 9.30, 8.10, 7.20, 9.50, 7.70, 8.65, 7.30,
            9.22, 8.38, 9.60, 7.85, 8.90, 8.25, 8.70, 7.15, 8.55, 8.00,
            8.88, 8.18, 8.95, 8.42, 9.45, 9.12, 9.00, 9.10, 8.35, 8.60
        };

        for (int i = 0; i < regs.length; i++) {
            list.add(new Student(regs[i], names[i], depts[i], cgpas[i],
                    names[i].toLowerCase().replace(" ", ".") + "@srmist.edu.in"));
        }
        return list;
    }

    public static ExperimentReport runExperiment(List<Student> students) {
        ExperimentReport report = new ExperimentReport();
        report.datasetSize = students.size();

        BST bst = new BST();
        AVLTree avl = new AVLTree();
        int hashCapacity = 53; // Prime modulo capacity
        HashTableLP hash = new HashTableLP(hashCapacity);
        report.hashCapacity = hashCapacity;

        // 1. Insertion phase
        for (Student s : students) {
            bst.insert(s);
            avl.insert(s);
            hash.insert(s);
        }

        report.bstHeight = bst.getHeight();
        report.avlHeight = avl.getHeight();
        report.avlRotations = avl.getTotalRotations();
        report.avlLL = avl.getLlRotations();
        report.avlRR = avl.getRrRotations();
        report.avlLR = avl.getLrRotations();
        report.avlRL = avl.getRlRotations();

        report.hashCollisions = hash.getTotalCollisions();
        report.hashLoadFactor = hash.getLoadFactor();

        report.bstInsertComps = bst.getTotalInsertionComparisons();
        report.avlInsertComps = avl.getTotalInsertionComparisons();
        report.hashInsertComps = hash.getTotalInsertionComparisons();

        // 2. Successful Search Phase (Search all 40 inserted students)
        long bstTotalSuccessComps = 0;
        long avlTotalSuccessComps = 0;
        long hashTotalSuccessComps = 0;

        for (Student s : students) {
            SearchResult bRes = bst.search(s.getRegNo());
            SearchResult aRes = avl.search(s.getRegNo());
            SearchResult hRes = hash.search(s.getRegNo());

            // BST
            bstTotalSuccessComps += bRes.getComparisons();
            report.bstSuccessMinComps = Math.min(report.bstSuccessMinComps, bRes.getComparisons());
            report.bstSuccessMaxComps = Math.max(report.bstSuccessMaxComps, bRes.getComparisons());

            // AVL
            avlTotalSuccessComps += aRes.getComparisons();
            report.avlSuccessMinComps = Math.min(report.avlSuccessMinComps, aRes.getComparisons());
            report.avlSuccessMaxComps = Math.max(report.avlSuccessMaxComps, aRes.getComparisons());

            // Hash
            hashTotalSuccessComps += hRes.getComparisons();
            report.hashSuccessMinComps = Math.min(report.hashSuccessMinComps, hRes.getComparisons());
            report.hashSuccessMaxComps = Math.max(report.hashSuccessMaxComps, hRes.getComparisons());
        }

        report.bstSuccessAvgComps = (double) bstTotalSuccessComps / students.size();
        report.avlSuccessAvgComps = (double) avlTotalSuccessComps / students.size();
        report.hashSuccessAvgComps = (double) hashTotalSuccessComps / students.size();

        // 3. Unsuccessful Search Phase (10 non-existent registration numbers)
        int[] missingKeys = {99, 111, 150, 200, 211, 250, 300, 311, 400, 411};
        long bstTotalFailComps = 0;
        long avlTotalFailComps = 0;
        long hashTotalFailComps = 0;

        for (int key : missingKeys) {
            SearchResult bRes = bst.search(key);
            SearchResult aRes = avl.search(key);
            SearchResult hRes = hash.search(key);

            // BST
            bstTotalFailComps += bRes.getComparisons();
            report.bstFailMinComps = Math.min(report.bstFailMinComps, bRes.getComparisons());
            report.bstFailMaxComps = Math.max(report.bstFailMaxComps, bRes.getComparisons());

            // AVL
            avlTotalFailComps += aRes.getComparisons();
            report.avlFailMinComps = Math.min(report.avlFailMinComps, aRes.getComparisons());
            report.avlFailMaxComps = Math.max(report.avlFailMaxComps, aRes.getComparisons());

            // Hash
            hashTotalFailComps += hRes.getComparisons();
            report.hashFailMinComps = Math.min(report.hashFailMinComps, hRes.getComparisons());
            report.hashFailMaxComps = Math.max(report.hashFailMaxComps, hRes.getComparisons());
        }

        report.bstFailAvgComps = (double) bstTotalFailComps / missingKeys.length;
        report.avlFailAvgComps = (double) avlTotalFailComps / missingKeys.length;
        report.hashFailAvgComps = (double) hashTotalFailComps / missingKeys.length;

        return report;
    }

    public static void printReport(ExperimentReport rep) {
        System.out.println("================================================================================");
        System.out.println("      SRM INSTITUTE OF SCIENCE AND TECHNOLOGY - TIRUCHIRAPPALLI");
        System.out.println("            CONTINUOUS LEARNING ASSESSMENT - 2 (CLA-2)");
        System.out.println("        ALGORITHM BATTLE EXPERIMENT: BST vs AVL vs HASHING");
        System.out.println("================================================================================");
        System.out.println(String.format("Dataset Size           : %d unique student records", rep.datasetSize));
        System.out.println(String.format("Hash Table Capacity    : %d slots (Prime modulo)", rep.hashCapacity));
        System.out.println(String.format("Hash Table Load Factor : %.2f (%.1f%% occupied)", rep.hashLoadFactor, rep.hashLoadFactor * 100));
        System.out.println(String.format("Hash Collisions Total  : %d collisions (Resolved via Linear Probing)", rep.hashCollisions));
        System.out.println(String.format("Tree Height (BST)      : %d levels", rep.bstHeight));
        System.out.println(String.format("Tree Height (AVL)      : %d levels (Strictly balanced O(log N))", rep.avlHeight));
        System.out.println(String.format("AVL Rotations Total    : %d (LL: %d, RR: %d, LR: %d, RL: %d)",
                rep.avlRotations, rep.avlLL, rep.avlRR, rep.avlLR, rep.avlRL));
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("                       PART D - ALGORITHM BATTLE TABLE");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Parameter", "BST", "AVL Tree", "Hashing (Lin. Prob)");
        System.out.println("---------------------------+-----------------+-----------------+-----------------");
        System.out.printf("%-26s | %-15d | %-15d | %-15s\n", "Tree Height", rep.bstHeight, rep.avlHeight, "N/A (Array)");
        System.out.printf("%-26s | %-15s | %-15d | %-15s\n", "Rotations Performed", "N/A", rep.avlRotations, "N/A");
        System.out.printf("%-26s | %-15s | %-15s | %-15d\n", "Collisions Observed", "N/A", "N/A", rep.hashCollisions);
        System.out.printf("%-26s | %-15.2f | %-15.2f | %-15.2f\n", "Avg Success Comparisons",
                rep.bstSuccessAvgComps, rep.avlSuccessAvgComps, rep.hashSuccessAvgComps);
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Success Comps (Min/Max)",
                rep.bstSuccessMinComps + " / " + rep.bstSuccessMaxComps,
                rep.avlSuccessMinComps + " / " + rep.avlSuccessMaxComps,
                rep.hashSuccessMinComps + " / " + rep.hashSuccessMaxComps);
        System.out.printf("%-26s | %-15.2f | %-15.2f | %-15.2f\n", "Avg Unsuccessful Comps",
                rep.bstFailAvgComps, rep.avlFailAvgComps, rep.hashFailAvgComps);
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Unsuccess Comps (Min/Max)",
                rep.bstFailMinComps + " / " + rep.bstFailMaxComps,
                rep.avlFailMinComps + " / " + rep.avlFailMaxComps,
                rep.hashFailMinComps + " / " + rep.hashFailMaxComps);
        System.out.printf("%-26s | %-15d | %-15d | %-15d\n", "Total Insertion Comps",
                rep.bstInsertComps, rep.avlInsertComps, rep.hashInsertComps);
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Theoretical Time (Avg)", "O(log N)", "O(log N)", "O(1)");
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Theoretical Time (Worst)", "O(N)", "O(log N)", "O(N)");
        System.out.printf("%-26s | %-15s | %-15s | %-15s\n", "Sorted Traversal Cost", "O(N) Inorder", "O(N) Inorder", "O(M log M) Sort");
        System.out.println("================================================================================");
    }

    public static void main(String[] args) {
        String path = "data/students.csv";
        if (args.length > 0) path = args[0];
        List<Student> students = loadDataset(path);
        ExperimentReport report = runExperiment(students);
        printReport(report);
    }
}
