package src;

import java.util.ArrayList;
import java.util.List;

/**
 * Binary Search Tree (BST) Implementation for Student Record Search.
 * Tracks comparisons during insertion and search, as well as tree height.
 */
public class BST {

    public static class BSTNode {
        public Student student;
        public BSTNode left;
        public BSTNode right;

        public BSTNode(Student student) {
            this.student = student;
            this.left = null;
            this.right = null;
        }
    }

    private BSTNode root;
    private int size;
    private long totalInsertionComparisons;

    public BST() {
        this.root = null;
        this.size = 0;
        this.totalInsertionComparisons = 0;
    }

    /**
     * Inserts a student record into the BST.
     * @param student record to insert
     * @return comparisons made during this insertion
     */
    public int insert(Student student) {
        int[] comps = new int[]{0};
        root = insertRec(root, student, comps);
        size++;
        totalInsertionComparisons += comps[0];
        return comps[0];
    }

    private BSTNode insertRec(BSTNode current, Student student, int[] comps) {
        if (current == null) {
            return new BSTNode(student);
        }
        comps[0]++;
        if (student.getRegNo() < current.student.getRegNo()) {
            current.left = insertRec(current.left, student, comps);
        } else if (student.getRegNo() > current.student.getRegNo()) {
            current.right = insertRec(current.right, student, comps);
        } else {
            // Duplicate registration number: update record
            current.student = student;
        }
        return current;
    }

    /**
     * Searches for a student by registration number.
     * @param regNo Key to search
     * @return SearchResult containing student, found flag, and comparison count
     */
    public SearchResult search(int regNo) {
        long start = System.nanoTime();
        int comparisons = 0;
        BSTNode current = root;

        while (current != null) {
            comparisons++;
            if (regNo == current.student.getRegNo()) {
                long duration = System.nanoTime() - start;
                return new SearchResult(current.student, true, comparisons, duration);
            } else if (regNo < current.student.getRegNo()) {
                current = current.left;
            } else {
                current = current.right;
            }
        }

        long duration = System.nanoTime() - start;
        return new SearchResult(null, false, comparisons, duration);
    }

    /**
     * Calculates the height of the BST.
     */
    public int getHeight() {
        return computeHeight(root);
    }

    private int computeHeight(BSTNode node) {
        if (node == null) return 0;
        return 1 + Math.max(computeHeight(node.left), computeHeight(node.right));
    }

    /**
     * Inorder Traversal (Left, Root, Right) gives sorted order of Registration Numbers.
     */
    public List<Student> inorderTraversal() {
        List<Student> list = new ArrayList<>();
        inorderRec(root, list);
        return list;
    }

    private void inorderRec(BSTNode node, List<Student> list) {
        if (node != null) {
            inorderRec(node.left, list);
            list.add(node.student);
            inorderRec(node.right, list);
        }
    }

    public int getSize() {
        return size;
    }

    public long getTotalInsertionComparisons() {
        return totalInsertionComparisons;
    }

    public BSTNode getRoot() {
        return root;
    }
}
