# SRM Institute of Science and Technology — Tiruchirappalli
## Continuous Learning Assessment – 2 (CLA-2) | Regulations 2021
### Course Assignment: ALGORITHM BATTLE — "WHICH DATA STRUCTURE WINS?"

![Java](https://img.shields.io/badge/Language-Java%2021-orange.svg)
![Python](https://img.shields.io/badge/Language-Python%203-blue.svg)
![Status](https://img.shields.io/badge/Assessment-Complete%20%26%20Tested-brightgreen.svg)
![Institution](https://img.shields.io/badge/SRM%20IST-Tiruchirappalli-blue.svg)

---

## 📌 Project Overview

This repository contains the complete implementation, mini-experiment benchmarking suite, and comprehensive technical defense report for **CLA-2: Algorithm Battle**.

* **Real-World Application**: **Student Record Search & Academic Information Management System**
* **Data Structures Evaluated**:
  1. **Binary Search Tree (BST)**
  2. **Self-Balancing AVL Tree** (with $LL, RR, LR, RL$ rotations)
  3. **Hash Table with Linear Probing** ($h(k) = k \pmod M$)
* **Dataset**: 40 realistic SRM IST student records across 4 engineering departments (CSE, ECE, IT, MECH).

---

## 📂 Repository Structure

```
SRM_DSA_CLA2_Algorithm_Battle/
├── src/
│   ├── Student.java                  # Student record entity (regNo, name, dept, cgpa, email)
│   ├── SearchResult.java             # Query result container (status, comparisons, duration)
│   ├── BST.java                      # Binary Search Tree (insert, search, height, inorder)
│   ├── AVLTree.java                  # AVL Tree (self-balancing via LL, RR, LR, RL rotations)
│   ├── HashTableLP.java              # Hash Table with Linear Probing collision resolution
│   ├── StudentBenchmark.java         # Automated experimental benchmark harness
│   └── Main.java                     # Interactive CLI & live faculty defense demonstration
├── data/
│   └── students.csv                  # Controlled dataset of 40 unique SRM IST student records
├── docs/
│   ├── REPORT.md                     # Complete academic report (Parts A, B, C, D, E)
│   └── VIVA_QUESTIONS_AND_DEFENSE_GUIDE.md # Viva guide & step-by-step key tracing
├── python_version/
│   └── algorithm_battle.py           # Standalone Python 3 implementation of the same battle
├── run.bat                           # 1-click execution script for Windows
├── run.sh                            # 1-click execution script for Linux / macOS
└── README.md                         # This file
```

---

## 🚀 How to Run

### Method 1: Windows (1-Click)
Simply double-click `run.bat` or run in PowerShell:
```cmd
run.bat
```

### Method 2: Command Line (Java)
```bash
# Navigate to the project root directory:
cd SRM_DSA_CLA2_Algorithm_Battle

# Compile all Java sources:
javac src/*.java

# Run the automated benchmark directly:
java -cp . src.StudentBenchmark

# Or launch the interactive CLI / Viva Demonstration suite:
java -cp . src.Main
```

### Method 3: Python (Alternative)
```bash
python python_version/algorithm_battle.py
```

---

## 📊 Live Experimental Results (From Real Execution)

```
================================================================================
      SRM INSTITUTE OF SCIENCE AND TECHNOLOGY - TIRUCHIRAPPALLI
            CONTINUOUS LEARNING ASSESSMENT - 2 (CLA-2)
        ALGORITHM BATTLE EXPERIMENT: BST vs AVL vs HASHING
================================================================================
Dataset Size           : 40 unique student records
Hash Table Capacity    : 53 slots (Prime modulo)
Hash Table Load Factor : 0.75 (75.5% occupied)
Hash Collisions Total  : 240 probe collision steps (12 home collisions)
Tree Height (BST)      : 9 levels
Tree Height (AVL)      : 6 levels (Strictly balanced O(log N))
AVL Rotations Total    : 11 (LL: 1, RR: 5, LR: 3, RL: 2)
```

### Part D – Algorithm Battle Comparison Table

| Parameter | Binary Search Tree (BST) | Self-Balancing AVL Tree | Hashing (Linear Probing) |
| :--- | :--- | :--- | :--- |
| **Tree Height** | 9 levels | **6 levels** | N/A (Flat array) |
| **Rotations Performed** | N/A | **11 rotations** | N/A |
| **Collisions Observed** | N/A | N/A | **240 probe collision steps** |
| **Avg Success Comparisons** | 5.90 | **4.60** | 7.00 |
| **Success Comps (Min / Max)**| 1 / 9 | **1 / 6** | 1 / 31 |
| **Avg Unsuccessful Comps** | 6.50 | **5.40** | 24.00 (Clustering) |
| **Unsuccess Comps (Min / Max)**| 1 / 8 | **5 / 6** | 1 / 36 |
| **Total Insertion Comps** | 196 | 156 | 280 |
| **Theoretical Time (Avg)** | $O(\log N)$ | $O(\log N)$ | $O(1)$ |
| **Theoretical Time (Worst)** | $O(N)$ (Degenerate) | **$O(\log N)$ (Strict)** | $O(N)$ (Clustering) |
| **Sorted Traversal Cost** | **$O(N)$ Inorder** | **$O(N)$ Inorder** | $O(M \log M)$ External Sort |

---

## 🏆 Part E – Final Verdict

> **Winner: Self-Balancing AVL Tree.**

### Empirical Justification:
1. **Guaranteed Bounded Height**: AVL tree compressed the tree height from 9 levels down to 6 levels via 11 rotations, ensuring no query ever exceeded 6 comparisons.
2. **Cluster-Free Predictability**: Linear Probing at $\alpha = 0.75$ suffered significant primary clustering (up to 36 comparisons on unsuccessful searches), whereas AVL maintained consistent, deterministic performance.
3. **Campus ERP Requirements**: Unlike Hashing, AVL naturally supports $O(N)$ sorted traversals for rank lists and $O(\log N + k)$ range queries for department lookups.

---

## 📤 GitHub & Google Classroom Submission Guide

### Step 1: Initialize Git and Push to Your GitHub Account
```bash
# 1. Open terminal inside the project directory:
cd SRM_DSA_CLA2_Algorithm_Battle

# 2. Initialize a git repository:
git init

# 3. Add all files:
git add .

# 4. Commit:
git commit -m "Complete CLA-2 DSA Algorithm Battle: BST vs AVL vs Hashing"

# 5. Create a new repository on your GitHub (e.g., 'SRM-DSA-CLA2-Algorithm-Battle')
# Link your local repo to GitHub:
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/<YOUR_REPO_NAME>.git

# 6. Push code:
git branch -M main
git push -u origin main
```

### Step 2: Submit to Google Classroom
1. Copy your GitHub repository URL: `https://github.com/<YOUR_GITHUB_USERNAME>/<YOUR_REPO_NAME>`
2. Attach the generated single zip file: `DSA_Algorithm_Battle_SRM.zip`
3. Paste your GitHub repository link in the Google Classroom private comment or submission box.
