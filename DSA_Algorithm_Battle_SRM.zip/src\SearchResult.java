package src;

/**
 * Encapsulates the result of a search query across any data structure,
 * recording comparisons and outcome for benchmarking.
 */
public class SearchResult {
    private final Student student;
    private final boolean found;
    private final int comparisons;
    private final long timeTakenNs;

    public SearchResult(Student student, boolean found, int comparisons, long timeTakenNs) {
        this.student = student;
        this.found = found;
        this.comparisons = comparisons;
        this.timeTakenNs = timeTakenNs;
    }

    public Student getStudent() {
        return student;
    }

    public boolean isFound() {
        return found;
    }

    public int getComparisons() {
        return comparisons;
    }

    public long getTimeTakenNs() {
        return timeTakenNs;
    }

    @Override
    public String toString() {
        return String.format("Found: %b | Comparisons: %d | Time: %d ns | Record: %s",
                found, comparisons, timeTakenNs, (found ? student.getName() : "None"));
    }
}
