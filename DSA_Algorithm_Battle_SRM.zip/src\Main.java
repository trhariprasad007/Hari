package src;

import java.util.List;
import java.util.Scanner;

/**
 * Main Application & Viva Defense Demonstration Console
 * SRM Institute of Science and Technology, Tiruchirappalli
 * CLA-2: Algorithm Battle - "Which Data Structure Wins?"
 */
public class Main {

    private static BST bst = new BST();
    private static AVLTree avl = new AVLTree();
    private static HashTableLP hash = new HashTableLP(53);
    private static List<Student> dataset;

    public static void initialize() {
        dataset = StudentBenchmark.loadDataset("data/students.csv");
        bst = new BST();
        avl = new AVLTree();
        hash = new HashTableLP(53);

        for (Student s : dataset) {
            bst.insert(s);
            avl.insert(s);
            hash.insert(s);
        }
    }

    public static void main(String[] args) {
        initialize();
        Scanner scanner = new Scanner(System.in);
        System.out.println("==========================================================================");
        System.out.println("  SRM IST TIRUCHIRAPPALLI - CONTINUOUS LEARNING ASSESSMENT - 2 (CLA-2)");
        System.out.println("     ALGORITHM BATTLE: BST vs AVL TREE vs HASHING WITH LINEAR PROBING");
        System.out.println("               Real-World Application: Student Record Search");
        System.out.println("==========================================================================");
        System.out.println("Dataset automatically loaded: " + dataset.size() + " student records.");

        while (true) {
            System.out.println("\n-------------------------------------------------------------");
            System.out.println("                         MAIN MENU");
            System.out.println("-------------------------------------------------------------");
            System.out.println("1. Run Mini-Experiment Benchmark (Part C & Part D Tables)");
            System.out.println("2. Search Student Record (Live Comparison & Comparison Counter)");
            System.out.println("3. Insert New Student (Viva Demo: Demonstrates Rebalancing & Probing)");
            System.out.println("4. Display Inorder Traversal (BST & AVL Sorted Order)");
            System.out.println("5. Inspect Hash Table Slots (Linear Probing Chains & Collisions)");
            System.out.println("6. Viva & Technical Defense Quick Summary");
            System.out.println("7. Reset & Reload Dataset");
            System.out.println("8. Exit Application");
            System.out.print("Enter your choice (1-8): ");

            String input = scanner.nextLine().trim();
            if (input.equals("1")) {
                StudentBenchmark.ExperimentReport rep = StudentBenchmark.runExperiment(dataset);
                StudentBenchmark.printReport(rep);
            } else if (input.equals("2")) {
                handleSearch(scanner);
            } else if (input.equals("3")) {
                handleInsert(scanner);
            } else if (input.equals("4")) {
                handleTraversals();
            } else if (input.equals("5")) {
                handleHashTableInspect();
            } else if (input.equals("6")) {
                handleVivaSummary();
            } else if (input.equals("7")) {
                initialize();
                System.out.println("Dataset successfully reloaded into all three data structures.");
            } else if (input.equals("8")) {
                System.out.println("Exiting Algorithm Battle Assessment Suite. Good luck with your Viva!");
                break;
            } else {
                System.out.println("Invalid selection. Please choose an option from 1 to 8.");
            }
        }
    }

    private static void handleSearch(Scanner scanner) {
        System.out.print("\nEnter Student Registration Number to Search (e.g. 1025, 1005, 9999): ");
        try {
            int regNo = Integer.parseInt(scanner.nextLine().trim());
            System.out.println("\n--- LIVE SEARCH COMPARISON FOR REG NO: " + regNo + " ---");

            SearchResult bRes = bst.search(regNo);
            SearchResult aRes = avl.search(regNo);
            SearchResult hRes = hash.search(regNo);

            System.out.printf("%-15s | %-10s | %-15s | %-12s\n", "Data Structure", "Status", "Comparisons", "Time (ns)");
            System.out.println("----------------+------------+-----------------+-------------");
            System.out.printf("%-15s | %-10s | %-15d | %-12d\n", "BST", (bRes.isFound() ? "FOUND" : "NOT FOUND"), bRes.getComparisons(), bRes.getTimeTakenNs());
            System.out.printf("%-15s | %-10s | %-15d | %-12d\n", "AVL Tree", (aRes.isFound() ? "FOUND" : "NOT FOUND"), aRes.getComparisons(), aRes.getTimeTakenNs());
            System.out.printf("%-15s | %-10s | %-15d | %-12d\n", "Hashing (LP)", (hRes.isFound() ? "FOUND" : "NOT FOUND"), hRes.getComparisons(), hRes.getTimeTakenNs());

            if (bRes.isFound()) {
                System.out.println("\nRecord Details Found:");
                System.out.println(bRes.getStudent());
            } else {
                System.out.println("\nNotice: Record does NOT exist in the student database.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter a valid integer registration number.");
        }
    }

    private static void handleInsert(Scanner scanner) {
        System.out.println("\n--- INSERT NEW STUDENT RECORD (VIVA DEMO) ---");
        try {
            System.out.print("Enter Registration Number (e.g. 1051): ");
            int reg = Integer.parseInt(scanner.nextLine().trim());
            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine().trim();
            System.out.print("Enter Department (CSE/ECE/IT/AIDS/MECH): ");
            String dept = scanner.nextLine().trim();
            System.out.print("Enter CGPA (0.0 - 10.0): ");
            double cgpa = Double.parseDouble(scanner.nextLine().trim());
            String email = name.toLowerCase().replace(" ", ".") + "@srmist.edu.in";

            Student newStudent = new Student(reg, name, dept, cgpa, email);

            int bstHBefore = bst.getHeight();
            int avlHBefore = avl.getHeight();
            int avlRotsBefore = avl.getTotalRotations();
            int hashCollBefore = hash.getTotalCollisions();

            int bstComps = bst.insert(newStudent);
            int avlComps = avl.insert(newStudent);
            int hashComps = hash.insert(newStudent);

            System.out.println("\nInsertion Results Across All 3 Data Structures:");
            System.out.println("1. BST: Inserted with " + bstComps + " comparisons. Height changed from " + bstHBefore + " -> " + bst.getHeight());
            System.out.println("2. AVL Tree: Inserted with " + avlComps + " comparisons. Height changed from " + avlHBefore + " -> " + avl.getHeight()
                    + " (New Rotations triggered: " + (avl.getTotalRotations() - avlRotsBefore) + ")");
            System.out.println("3. Hashing: Inserted into slot " + hash.hash(reg) + " with " + hashComps + " comparisons. "
                    + "(Collisions triggered: " + (hash.getTotalCollisions() - hashCollBefore) + ", Current Load Factor: "
                    + String.format("%.2f", hash.getLoadFactor()) + ")");
        } catch (Exception e) {
            System.out.println("Error: Invalid input format. " + e.getMessage());
        }
    }

    private static void handleTraversals() {
        System.out.println("\n--- INORDER TRAVERSAL (BST & AVL) ---");
        System.out.println("Demonstrating fundamental property: Inorder traversal visits nodes in ASCENDING order of key.");
        List<Student> bstList = bst.inorderTraversal();
        System.out.println("\nFirst 10 records from BST Inorder Traversal:");
        for (int i = 0; i < Math.min(10, bstList.size()); i++) {
            System.out.println((i + 1) + ". " + bstList.get(i));
        }
        System.out.println("... Total sorted records in BST: " + bstList.size());

        List<Student> avlList = avl.inorderTraversal();
        System.out.println("\nFirst 10 records from AVL Inorder Traversal:");
        for (int i = 0; i < Math.min(10, avlList.size()); i++) {
            System.out.println((i + 1) + ". " + avlList.get(i));
        }
        System.out.println("... Total sorted records in AVL: " + avlList.size());
    }

    private static void handleHashTableInspect() {
        System.out.println("\n--- HASH TABLE SLOTS & LINEAR PROBING INSPECTION ---");
        System.out.println(String.format("Capacity: %d | Occupied: %d | Load Factor: %.2f | Total Collisions: %d",
                hash.getCapacity(), hash.getSize(), hash.getLoadFactor(), hash.getTotalCollisions()));
        System.out.println("Index | Key (RegNo) | Home Hash | Probes Needed | Student Name");
        System.out.println("------+-------------+-----------+---------------+---------------------");
        HashTableLP.HashEntry[] table = hash.getTable();
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null) {
                System.out.printf("%-5d | %-11d | %-9d | %-13d | %s\n",
                        i, table[i].student.getRegNo(), table[i].initialHash,
                        table[i].probesToPlace, table[i].student.getName());
            } else {
                System.out.printf("%-5d | %-11s | %-9s | %-13s | [EMPTY SLOT]\n", i, "--", "--", "--");
            }
        }
    }

    private static void handleVivaSummary() {
        System.out.println("\n==========================================================================");
        System.out.println("                  VIVA DEFENSE QUICK SUMMARY & INSIGHTS");
        System.out.println("==========================================================================");
        System.out.println("Q1: Which Data Structure wins?");
        System.out.println("Ans: For purely exact-match key search (e.g. find student by RegNo):");
        System.out.println("     -> HASHING WINS with average comparisons ~1.3 to 1.8 (approaching O(1)).");
        System.out.println("     For general campus administrative systems requiring sorted range queries:");
        System.out.println("     -> AVL TREE WINS because it guarantees strict O(log N) balance (height <= 6)");
        System.out.println("        and provides O(N) Inorder traversal for student merit lists.");
        System.out.println("\nQ2: Why not simple BST?");
        System.out.println("Ans: BST has no self-balancing guarantee. If records arrive pre-sorted or");
        System.out.println("     in skewed order, BST degrades into a linked list with O(N) worst-case time.");
        System.out.println("\nQ3: What causes collisions in Linear Probing?");
        System.out.println("Ans: When two keys hash to the same index (h(k1) == h(k2)) or when a key");
        System.out.println("     probes into an occupied slot due to primary clustering.");
        System.out.println("==========================================================================");
    }
}
