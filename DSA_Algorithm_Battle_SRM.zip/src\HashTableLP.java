package src;

import java.util.ArrayList;
import java.util.List;

/**
 * Hash Table Implementation with Linear Probing for Collision Resolution.
 * Uses division modulo hash function: h(k) = k % Capacity.
 * Resolves collisions using: index = (h(k) + i) % Capacity.
 */
public class HashTableLP {

    public static class HashEntry {
        public Student student;
        public int initialHash;
        public int probesToPlace;

        public HashEntry(Student student, int initialHash, int probesToPlace) {
            this.student = student;
            this.initialHash = initialHash;
            this.probesToPlace = probesToPlace;
        }
    }

    private final int capacity;
    private int size;
    private final HashEntry[] table;
    private int totalCollisions;
    private long totalInsertionComparisons;

    public HashTableLP(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.table = new HashEntry[capacity];
        this.totalCollisions = 0;
        this.totalInsertionComparisons = 0;
    }

    /**
     * Hash function: Division Modulo Method
     */
    public int hash(int regNo) {
        return Math.abs(regNo) % capacity;
    }

    /**
     * Inserts a student record using Linear Probing.
     * @param student record to insert
     * @return comparisons made during insertion
     */
    public int insert(Student student) {
        if (size >= capacity) {
            throw new IllegalStateException("Hash table overflow: Table is completely full!");
        }

        int key = student.getRegNo();
        int homeIndex = hash(key);
        int comparisons = 0;
        int probes = 0;

        for (int i = 0; i < capacity; i++) {
            int index = (homeIndex + i) % capacity;
            comparisons++;

            if (table[index] == null) {
                // Empty slot found: place student
                table[index] = new HashEntry(student, homeIndex, probes);
                size++;
                totalInsertionComparisons += comparisons;
                return comparisons;
            } else if (table[index].student.getRegNo() == key) {
                // Duplicate key: update record
                table[index].student = student;
                totalInsertionComparisons += comparisons;
                return comparisons;
            } else {
                // Collision encountered with another key
                totalCollisions++;
                probes++;
            }
        }

        totalInsertionComparisons += comparisons;
        return comparisons;
    }

    /**
     * Searches for a student by registration number using Linear Probing.
     */
    public SearchResult search(int regNo) {
        long start = System.nanoTime();
        int homeIndex = hash(regNo);
        int comparisons = 0;

        for (int i = 0; i < capacity; i++) {
            int index = (homeIndex + i) % capacity;
            comparisons++;

            if (table[index] == null) {
                // Empty slot encountered -> item not in hash table
                long duration = System.nanoTime() - start;
                return new SearchResult(null, false, comparisons, duration);
            }

            if (table[index].student.getRegNo() == regNo) {
                // Key found
                long duration = System.nanoTime() - start;
                return new SearchResult(table[index].student, true, comparisons, duration);
            }
        }

        // Entire table probed without match
        long duration = System.nanoTime() - start;
        return new SearchResult(null, false, comparisons, duration);
    }

    public int getCapacity() {
        return capacity;
    }

    public int getSize() {
        return size;
    }

    public double getLoadFactor() {
        return (double) size / capacity;
    }

    public int getTotalCollisions() {
        return totalCollisions;
    }

    public long getTotalInsertionComparisons() {
        return totalInsertionComparisons;
    }

    public HashEntry[] getTable() {
        return table;
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        for (HashEntry entry : table) {
            if (entry != null) {
                list.add(entry.student);
            }
        }
        return list;
    }
}
