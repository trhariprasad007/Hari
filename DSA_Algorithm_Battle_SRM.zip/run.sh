#!/usr/bin/env bash
echo "======================================================================="
echo "  SRM INSTITUTE OF SCIENCE AND TECHNOLOGY - TIRUCHIRAPPALLI"
echo "     CLA-2: ALGORITHM BATTLE - WHICH DATA STRUCTURE WINS?"
echo "======================================================================="
echo ""
echo "[1/2] Compiling Java source files..."
javac src/*.java
if [ $? -ne 0 ]; then
    echo "[ERROR] Compilation failed! Ensure JDK 11+ is installed."
    exit 1
fi
echo "[SUCCESS] Compilation successful."
echo ""
echo "[2/2] Running Main Interactive Application..."
java -cp . src.Main
