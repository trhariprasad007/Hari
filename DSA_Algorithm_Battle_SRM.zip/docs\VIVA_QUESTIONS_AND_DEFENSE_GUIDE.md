# SRM INSTITUTE OF SCIENCE AND TECHNOLOGY — TIRUCHIRAPPALLI
## Continuous Learning Assessment - 2 (CLA-2)
### Viva Voce & Technical Defense Guide: "Algorithm Battle"

> **Faculty Expectation (from Rubrics Item 7 & 8):**
> *"During the technical defense/viva, the faculty may provide a new value or search key and ask you to demonstrate or explain how each data structure handles it. Each student must understand and explain the submitted work."*

---

## 1. How Each Data Structure Handles a New Key During Viva

Suppose your faculty examiner hands you a new key: **`regNo = 215`** (or **`1051`**):

### Scenario A: Search Operation for `regNo = 215`

#### 1. In Binary Search Tree (BST)
1. Start at the root node.
2. Compare target `215` with current node's registration number.
3. If `215 == node.regNo`, record is found.
4. If `215 < node.regNo`, traverse to `node.left`.
5. If `215 > node.regNo`, traverse to `node.right`.
6. Repeat step 2 until matching node is found or a `null` pointer is reached.
7. If `null` is reached, declare **"Record Not Found"** and report the total comparisons made (which equals the search path depth).

#### 2. In AVL Tree
1. Search algorithm is identical to BST: binary decisions at each node.
2. Key difference during defense: Explain to the faculty that **because the AVL tree is guaranteed to have a maximum height of $\le 1.44 \log_2(N+2)$**, the number of comparisons for 40 records will **never exceed 6 comparisons**, whereas an unbalanced BST could take up to 9 or more comparisons.

#### 3. In Hashing with Linear Probing
1. Compute the home index using the hash function:
   $$\text{Home Index} = 215 \pmod{53} = 3 \quad (\text{since } 215 = 4 \times 53 + 3)$$
2. Inspect `table[3]`:
   * If `table[3] == null`: Stop immediately! The key does not exist. (Total comparisons = 1).
   * If `table[3].regNo == 215`: Key found! Return student record. (Total comparisons = 1).
   * If `table[3]` contains another student (e.g. regNo 109): Collision! Sequentially probe:
     * Check index $(3 + 1) \pmod{53} = 4$
     * Check index $(3 + 2) \pmod{53} = 5$
     * Continue until either `regNo == 215` is found OR an empty slot (`null`) is encountered.
   * If an empty slot is encountered, report **"Unsuccessful search"** with the total probe count.

---

### Scenario B: Insertion of a New Student (e.g., `regNo = 1051`, Name: "Arun", Dept: "CSE")

#### 1. In Binary Search Tree (BST)
* Traverse standard binary search path until reaching `null`.
* Allocate new `BSTNode` and attach it as left or right child of parent.
* **No balancing is performed.** Tree height may increase by 1.

#### 2. In AVL Tree (Self-Balancing with Rotations)
* Insert node recursively just like BST.
* On the return path (backtracking up recursion stack):
  1. Update `height = 1 + max(height(left), height(right))`.
  2. Compute `Balance Factor = height(left) - height(right)`.
  3. If $|BF| > 1$, rebalancing is triggered:
     * **Case 1 (Left-Left / LL)**: $BF > 1$ and `newKey < node.left.regNo` $\rightarrow$ Perform **Single Right Rotation**.
     * **Case 2 (Right-Right / RR)**: $BF < -1$ and `newKey > node.right.regNo` $\rightarrow$ Perform **Single Left Rotation**.
     * **Case 3 (Left-Right / LR)**: $BF > 1$ and `newKey > node.left.regNo` $\rightarrow$ Perform **Left Rotate on left child**, then **Right Rotate on current node**.
     * **Case 4 (Right-Left / RL)**: $BF < -1$ and `newKey < node.right.regNo` $\rightarrow$ Perform **Right Rotate on right child**, then **Left Rotate on current node**.

##### ASCII Diagram of Rotations:
```
Single Right Rotation (LL Case):
        y (BF = +2)               x (BF = 0)
       / \                       / \
      x   T3       -->          T1   y
     / \                            / \
    T1  T2                         T2  T3

Single Left Rotation (RR Case):
      x (BF = -2)                 y (BF = 0)
     / \                         / \
    T1  y          -->          x   T3
       / \                     / \
      T2  T3                  T1  T2
```

#### 3. In Hashing with Linear Probing
1. Calculate home slot: $h(1051) = 1051 \pmod{53} = 44$.
2. Check `table[44]`:
   * If empty: place student into slot 44. Comparisons = 1, Collisions = 0.
   * If occupied: increment collision counter, probe index 45, 46, ... until empty slot is found.
3. Update table size and recalculate load factor: $\alpha = \frac{\text{size}}{\text{capacity}}$.

---

## 2. Top 15 Viva Questions & Concise Model Answers

### Q1: What was your chosen real-world application, and why?
**Answer**: Student Record Search & Academic Management System for SRM IST. It requires fast point lookups by Registration Number for portal logins and fee verifications, as well as sorted traversals for merit lists and range queries for branch filtering.

### Q2: What is the Balance Factor in an AVL Tree, and what are its valid values?
**Answer**: 
$$\text{Balance Factor} = \text{Height of Left Subtree} - \text{Height of Right Subtree}$$
In a valid AVL tree, the balance factor at every single node must belong to $\{-1, 0, +1\}$. If $|BF| \ge 2$, the node is unbalanced and rebalanced via rotations.

### Q3: Why is the worst-case time complexity of BST $O(N)$?
**Answer**: If keys are inserted in sorted order (e.g., 101, 102, 103, 104) or reverse-sorted order, every new node attaches to the same side without branching. The tree degenerates into a linear linked list of height $N$, requiring $O(N)$ comparisons to search.

### Q4: How does AVL Tree prevent this $O(N)$ degeneration?
**Answer**: AVL checks balance factors during every insertion and deletion. If an insertion creates height imbalance, it performs constant-time $O(1)$ rotations ($LL, RR, LR, RL$) to keep height strictly bounded at $O(\log N)$. Thus, worst-case search is always $O(\log N)$.

### Q5: What is "Primary Clustering" in Linear Probing?
**Answer**: Primary clustering occurs when multiple keys hash into neighboring slots, forming contiguous occupied blocks. Any subsequent key that hashes anywhere into this block must probe sequentially through the entire cluster, making the cluster grow even longer. This severely degrades search and insertion performance when load factor $\alpha > 0.7$.

### Q6: What was the load factor in your mini-experiment?
**Answer**: With 40 student records and table capacity $M = 53$, our load factor was:
$$\alpha = \frac{40}{53} \approx 0.755 \quad (75.5\%)$$
This load factor was intentionally chosen above 0.70 to demonstrate real-world collision resolution and primary clustering during the assessment.

### Q7: Why did you choose a prime number (53) as the Hash Table capacity?
**Answer**: A prime table capacity ensures that the modulo division function $h(k) = k \pmod M$ distributes keys uniformly across slots. If $M$ is a composite number with common factors shared with the keys (such as multiples of 10 or 2), keys clump into specific buckets, causing excessive collisions.

### Q8: What tree traversal did you use, and why does it produce sorted order?
**Answer**: We implemented **Inorder Traversal** $(Left \rightarrow Root \rightarrow Right)$. In both BST and AVL, all keys in the left subtree are strictly smaller than the root, and all keys in the right subtree are strictly larger. Visiting Left first, then Root, then Right naturally visits keys in ascending numerical order in $O(N)$ time.

### Q9: Can Hashing produce a sorted list in $O(N)$ time?
**Answer**: No. Hashing distributes keys pseudo-randomly across table slots based on modulo arithmetic. To produce a sorted student list, all non-empty entries must be extracted into an auxiliary array and sorted using an algorithm like QuickSort or MergeSort, taking $O(M \log M)$ time and extra memory.

### Q10: How many rotations did your AVL tree perform for the 40 records?
**Answer**: Our AVL tree performed **11 total rotations** (1 LL, 5 RR, 3 LR, and 2 RL). These rotations kept the AVL tree height at exactly **6 levels**, compared to **9 levels** for the unbalanced BST.

### Q11: What were the average search comparisons in your experiment?
**Answer**:
* **AVL Tree**: 4.60 comparisons (Successful) | 5.40 comparisons (Unsuccessful)
* **BST**: 5.90 comparisons (Successful) | 6.50 comparisons (Unsuccessful)
* **Hashing (Linear Probing)**: 7.00 comparisons (Successful) | 24.00 comparisons (Unsuccessful, due to primary clustering at $\alpha=0.75$).

### Q12: Which data structure would you recommend if the system only needed fast login verification?
**Answer**: If the system solely performs point-query key matching without range queries or sorted lists, and memory allows allocating a table with load factor $\alpha \le 0.50$, **Hashing** is preferred because its average lookup is near $O(1)$ (~1.3 comparisons).

### Q13: Why did you pick AVL as the overall winner for campus ERP?
**Answer**: An academic ERP requires sorted merit rankings, department range queries, and predictable response times. AVL provides guaranteed $O(\log N)$ search latency without risk of primary clustering or degenerate linked-list behavior, while natively supporting $O(N)$ sorted in-order traversal.

### Q14: How does deletion differ between BST and AVL?
**Answer**: In BST, after replacing a node with its inorder predecessor/successor, deletion is finished. In AVL, after node removal, the tree must backtrack up to the root, recalculating balance factors and potentially performing multiple rotations ($O(\log N)$ rotations) to rebalance.

### Q15: How is an unsuccessful search detected in Linear Probing?
**Answer**: Probing starts at $h(k)$ and moves sequentially. As soon as an empty slot (`null`) is encountered, we know the key was never inserted; otherwise, it would have occupied that slot during insertion. Hence, the search halts and reports unsuccessful.

---

## 3. Quick Demonstration Instructions for Viva

To run the interactive demonstration in front of your examiner:
```powershell
# In PowerShell:
cd "c:\Users\NAVAL KISHOR\Downloads\expenssssss\SRM_DSA_CLA2_Algorithm_Battle"
.\run.bat
```
* **To show full experiment table**: Choose Menu Option `1`.
* **To test any key given by faculty**: Choose Menu Option `2` and type the key.
* **To demonstrate new insertion & rebalancing live**: Choose Menu Option `3`.
* **To prove sorted order**: Choose Menu Option `4`.
* **To show collision chains and linear probing slots**: Choose Menu Option `5`.
