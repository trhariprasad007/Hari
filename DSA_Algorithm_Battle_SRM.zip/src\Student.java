package src;

/**
 * Student Record Entity
 * Represents an individual student record at SRM IST.
 */
public class Student {
    private int regNo;
    private String name;
    private String department;
    private double cgpa;
    private String email;

    public Student(int regNo, String name, String department, double cgpa, String email) {
        this.regNo = regNo;
        this.name = name;
        this.department = department;
        this.cgpa = cgpa;
        this.email = email;
    }

    public int getRegNo() {
        return regNo;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public double getCgpa() {
        return cgpa;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return String.format("[RegNo: %d | Name: %-18s | Dept: %-5s | CGPA: %.2f | Email: %s]",
                regNo, name, department, cgpa, email);
    }
}
