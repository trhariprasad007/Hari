#!/usr/bin/env python3
"""
SRM Institute of Science and Technology, Tiruchirappalli
Continuous Learning Assessment - 2 (CLA-2)
Course Assignment: Algorithm Battle - 'Which Data Structure Wins?'
Real-World Application: Student Record Search

Author: SRM B.Tech CSE Student
Data Structures Implemented:
1. Binary Search Tree (BST)
2. AVL Tree (Self-balancing BST)
3. Hashing with Linear Probing
"""

import csv
import os
import sys
import time

class Student:
    def __init__(self, reg_no, name, department, cgpa, email):
        self.reg_no = int(reg_no)
        self.name = name.strip()
        self.department = department.strip()
        self.cgpa = float(cgpa)
        self.email = email.strip()

    def __str__(self):
        return f"[RegNo: {self.reg_no} | Name: {self.name:<18} | Dept: {self.department:<5} | CGPA: {self.cgpa:.2f} | Email: {self.email}]"


class BSTNode:
    def __init__(self, student):
        self.student = student
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None
        self.size = 0
        self.total_insertion_comps = 0

    def insert(self, student):
        comps = [0]
        self.root = self._insert_rec(self.root, student, comps)
        self.size += 1
        self.total_insertion_comps += comps[0]
        return comps[0]

    def _insert_rec(self, node, student, comps):
        if node is None:
            return BSTNode(student)
        comps[0] += 1
        if student.reg_no < node.student.reg_no:
            node.left = self._insert_rec(node.left, student, comps)
        elif student.reg_no > node.student.reg_no:
            node.right = self._insert_rec(node.right, student, comps)
        else:
            node.student = student
        return node

    def search(self, reg_no):
        comparisons = 0
        curr = self.root
        start = time.perf_counter_ns()
        while curr:
            comparisons += 1
            if reg_no == curr.student.reg_no:
                duration = time.perf_counter_ns() - start
                return (curr.student, True, comparisons, duration)
            elif reg_no < curr.student.reg_no:
                curr = curr.left
            else:
                curr = curr.right
        duration = time.perf_counter_ns() - start
        return (None, False, comparisons, duration)

    def get_height(self):
        return self._height_rec(self.root)

    def _height_rec(self, node):
        if node is None:
            return 0
        return 1 + max(self._height_rec(node.left), self._height_rec(node.right))

    def inorder(self):
        res = []
        self._inorder_rec(self.root, res)
        return res

    def _inorder_rec(self, node, res):
        if node:
            self._inorder_rec(node.left, res)
            res.append(node.student)
            self._inorder_rec(node.right, res)


class AVLNode:
    def __init__(self, student):
        self.student = student
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None
        self.size = 0
        self.total_insertion_comps = 0
        self.ll_rot = 0
        self.rr_rot = 0
        self.lr_rot = 0
        self.rl_rot = 0

    def _height(self, node):
        return 0 if node is None else node.height

    def _balance(self, node):
        return 0 if node is None else self._height(node.left) - self._height(node.right)

    def _right_rotate(self, y):
        x = y.left
        T2 = x.right
        x.right = y
        y.left = T2
        y.height = max(self._height(y.left), self._height(y.right)) + 1
        x.height = max(self._height(x.left), self._height(x.right)) + 1
        return x

    def _left_rotate(self, x):
        y = x.right
        T2 = y.left
        y.left = x
        x.right = T2
        x.height = max(self._height(x.left), self._height(x.right)) + 1
        y.height = max(self._height(y.left), self._height(y.right)) + 1
        return y

    def insert(self, student):
        comps = [0]
        self.root = self._insert_rec(self.root, student, comps)
        self.size += 1
        self.total_insertion_comps += comps[0]
        return comps[0]

    def _insert_rec(self, node, student, comps):
        if node is None:
            return AVLNode(student)
        comps[0] += 1
        if student.reg_no < node.student.reg_no:
            node.left = self._insert_rec(node.left, student, comps)
        elif student.reg_no > node.student.reg_no:
            node.right = self._insert_rec(node.right, student, comps)
        else:
            node.student = student
            return node

        node.height = 1 + max(self._height(node.left), self._height(node.right))
        balance = self._balance(node)

        # 4 Rotation Cases
        if balance > 1 and student.reg_no < node.left.student.reg_no:
            self.ll_rot += 1
            return self._right_rotate(node)
        if balance < -1 and student.reg_no > node.right.student.reg_no:
            self.rr_rot += 1
            return self._left_rotate(node)
        if balance > 1 and student.reg_no > node.left.student.reg_no:
            self.lr_rot += 1
            node.left = self._left_rotate(node.left)
            return self._right_rotate(node)
        if balance < -1 and student.reg_no < node.right.student.reg_no:
            self.rl_rot += 1
            node.right = self._right_rotate(node.right)
            return self._left_rotate(node)

        return node

    def search(self, reg_no):
        comparisons = 0
        curr = self.root
        start = time.perf_counter_ns()
        while curr:
            comparisons += 1
            if reg_no == curr.student.reg_no:
                duration = time.perf_counter_ns() - start
                return (curr.student, True, comparisons, duration)
            elif reg_no < curr.student.reg_no:
                curr = curr.left
            else:
                curr = curr.right
        duration = time.perf_counter_ns() - start
        return (None, False, comparisons, duration)

    def get_height(self):
        return self._height(self.root)

    def inorder(self):
        res = []
        self._inorder_rec(self.root, res)
        return res

    def _inorder_rec(self, node, res):
        if node:
            self._inorder_rec(node.left, res)
            res.append(node.student)
            self._inorder_rec(node.right, res)

    def total_rotations(self):
        return self.ll_rot + self.rr_rot + self.lr_rot + self.rl_rot


class HashEntry:
    def __init__(self, student, initial_hash, probes):
        self.student = student
        self.initial_hash = initial_hash
        self.probes = probes


class HashTableLP:
    def __init__(self, capacity=53):
        self.capacity = capacity
        self.size = 0
        self.table = [None] * capacity
        self.total_collisions = 0
        self.total_insertion_comps = 0

    def hash(self, key):
        return abs(key) % self.capacity

    def insert(self, student):
        if self.size >= self.capacity:
            raise OverflowError("Hash table full")
        key = student.reg_no
        home = self.hash(key)
        probes = 0
        for i in range(self.capacity):
            idx = (home + i) % self.capacity
            self.total_insertion_comps += 1
            if self.table[idx] is None:
                self.table[idx] = HashEntry(student, home, probes)
                self.size += 1
                return i + 1
            elif self.table[idx].student.reg_no == key:
                self.table[idx].student = student
                return i + 1
            else:
                self.total_collisions += 1
                probes += 1
        return self.capacity

    def search(self, reg_no):
        home = self.hash(reg_no)
        comparisons = 0
        start = time.perf_counter_ns()
        for i in range(self.capacity):
            idx = (home + i) % self.capacity
            comparisons += 1
            if self.table[idx] is None:
                duration = time.perf_counter_ns() - start
                return (None, False, comparisons, duration)
            if self.table[idx].student.reg_no == reg_no:
                duration = time.perf_counter_ns() - start
                return (self.table[idx].student, True, comparisons, duration)
        duration = time.perf_counter_ns() - start
        return (None, False, comparisons, duration)


def load_dataset():
    path = os.path.join(os.path.dirname(__file__), "..", "data", "students.csv")
    students = []
    if os.path.exists(path):
        with open(path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                students.append(Student(row["regNo"], row["name"], row["department"], row["cgpa"], row["email"]))
    return students


def run_benchmark():
    students = load_dataset()
    bst = BST()
    avl = AVLTree()
    hash_tbl = HashTableLP(53)

    for s in students:
        bst.insert(s)
        avl.insert(s)
        hash_tbl.insert(s)

    # Successful searches
    b_s_comps = [bst.search(s.reg_no)[2] for s in students]
    a_s_comps = [avl.search(s.reg_no)[2] for s in students]
    h_s_comps = [hash_tbl.search(s.reg_no)[2] for s in students]

    # Unsuccessful searches
    missing = [99, 111, 150, 200, 211, 250, 300, 311, 400, 411]
    b_u_comps = [bst.search(k)[2] for k in missing]
    a_u_comps = [avl.search(k)[2] for k in missing]
    h_u_comps = [hash_tbl.search(k)[2] for k in missing]

    print("=" * 80)
    print("      SRM INSTITUTE OF SCIENCE AND TECHNOLOGY - TIRUCHIRAPPALLI")
    print("            CONTINUOUS LEARNING ASSESSMENT - 2 (CLA-2)")
    print("        ALGORITHM BATTLE EXPERIMENT: BST vs AVL vs HASHING")
    print("=" * 80)
    print(f"Dataset Size           : {len(students)} unique student records")
    print(f"Hash Table Capacity    : {hash_tbl.capacity} slots (Prime modulo)")
    print(f"Hash Table Load Factor : {len(students)/hash_tbl.capacity:.2f} ({len(students)/hash_tbl.capacity*100:.1f}% occupied)")
    print(f"Hash Collisions Total  : {hash_tbl.total_collisions} probe collisions")
    print(f"Tree Height (BST)      : {bst.get_height()} levels")
    print(f"Tree Height (AVL)      : {avl.get_height()} levels (Strictly balanced)")
    print(f"AVL Rotations Total    : {avl.total_rotations()} (LL: {avl.ll_rot}, RR: {avl.rr_rot}, LR: {avl.lr_rot}, RL: {avl.rl_rot})")
    print("-" * 80)
    print("                       PART D - ALGORITHM BATTLE TABLE")
    print("-" * 80)
    print(f"{'Parameter':<26} | {'BST':<15} | {'AVL Tree':<15} | {'Hashing (Lin. Prob)':<15}")
    print("-" * 27 + "+" + "-" * 17 + "+" + "-" * 17 + "+" + "-" * 17)
    print(f"{'Tree Height':<26} | {bst.get_height():<15} | {avl.get_height():<15} | {'N/A (Array)':<15}")
    print(f"{'Rotations Performed':<26} | {'N/A':<15} | {avl.total_rotations():<15} | {'N/A':<15}")
    print(f"{'Collisions Observed':<26} | {'N/A':<15} | {'N/A':<15} | {hash_tbl.total_collisions:<15}")
    print(f"{'Avg Success Comparisons':<26} | {sum(b_s_comps)/len(b_s_comps):<15.2f} | {sum(a_s_comps)/len(a_s_comps):<15.2f} | {sum(h_s_comps)/len(h_s_comps):<15.2f}")
    print(f"{'Success Comps (Min/Max)':<26} | {f'{min(b_s_comps)} / {max(b_s_comps)}':<15} | {f'{min(a_s_comps)} / {max(a_s_comps)}':<15} | {f'{min(h_s_comps)} / {max(h_s_comps)}':<15}")
    print(f"{'Avg Unsuccessful Comps':<26} | {sum(b_u_comps)/len(b_u_comps):<15.2f} | {sum(a_u_comps)/len(a_u_comps):<15.2f} | {sum(h_u_comps)/len(h_u_comps):<15.2f}")
    print(f"{'Unsuccess Comps (Min/Max)':<26} | {f'{min(b_u_comps)} / {max(b_u_comps)}':<15} | {f'{min(a_u_comps)} / {max(a_u_comps)}':<15} | {f'{min(h_u_comps)} / {max(h_u_comps)}':<15}")
    print(f"{'Total Insertion Comps':<26} | {bst.total_insertion_comps:<15} | {avl.total_insertion_comps:<15} | {hash_tbl.total_insertion_comps:<15}")
    print(f"{'Theoretical Time (Avg)':<26} | {'O(log N)':<15} | {'O(log N)':<15} | {'O(1)':<15}")
    print(f"{'Theoretical Time (Worst)':<26} | {'O(N)':<15} | {'O(log N)':<15} | {'O(N)':<15}")
    print(f"{'Sorted Traversal Cost':<26} | {'O(N) Inorder':<15} | {'O(N) Inorder':<15} | {'O(M log M) Sort':<15}")
    print("=" * 80)


if __name__ == "__main__":
    run_benchmark()
