package src;

import java.util.ArrayList;
import java.util.List;

/**
 * Self-Balancing AVL Tree Implementation for Student Record Search.
 * Maintains O(log N) worst-case height via Left-Left, Right-Right,
 * Left-Right, and Right-Left rotations.
 */
public class AVLTree {

    public static class AVLNode {
        public Student student;
        public AVLNode left;
        public AVLNode right;
        public int height;

        public AVLNode(Student student) {
            this.student = student;
            this.left = null;
            this.right = null;
            this.height = 1;
        }
    }

    private AVLNode root;
    private int size;
    private long totalInsertionComparisons;
    private int llRotations;
    private int rrRotations;
    private int lrRotations;
    private int rlRotations;

    public AVLTree() {
        this.root = null;
        this.size = 0;
        this.totalInsertionComparisons = 0;
        this.llRotations = 0;
        this.rrRotations = 0;
        this.lrRotations = 0;
        this.rlRotations = 0;
    }

    private int height(AVLNode node) {
        return (node == null) ? 0 : node.height;
    }

    private int getBalance(AVLNode node) {
        return (node == null) ? 0 : height(node.left) - height(node.right);
    }

    private AVLNode rightRotate(AVLNode y) {
        AVLNode x = y.left;
        AVLNode T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;

        // Update heights
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }

    private AVLNode leftRotate(AVLNode x) {
        AVLNode y = x.right;
        AVLNode T2 = y.left;

        // Perform rotation
        y.left = x;
        x.right = T2;

        // Update heights
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }

    /**
     * Inserts a student and balances the tree.
     * @param student record to insert
     * @return comparisons made during insertion
     */
    public int insert(Student student) {
        int[] comps = new int[]{0};
        root = insertRec(root, student, comps);
        size++;
        totalInsertionComparisons += comps[0];
        return comps[0];
    }

    private AVLNode insertRec(AVLNode node, Student student, int[] comps) {
        // Standard BST insertion
        if (node == null) {
            return new AVLNode(student);
        }

        comps[0]++;
        if (student.getRegNo() < node.student.getRegNo()) {
            node.left = insertRec(node.left, student, comps);
        } else if (student.getRegNo() > node.student.getRegNo()) {
            node.right = insertRec(node.right, student, comps);
        } else {
            // Duplicate registration number: update record
            node.student = student;
            return node;
        }

        // Update height of ancestor node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Get balance factor to check whether this node became unbalanced
        int balance = getBalance(node);

        // 4 Balance Cases:
        // Case 1: Left-Left (LL)
        if (balance > 1 && student.getRegNo() < node.left.student.getRegNo()) {
            llRotations++;
            return rightRotate(node);
        }

        // Case 2: Right-Right (RR)
        if (balance < -1 && student.getRegNo() > node.right.student.getRegNo()) {
            rrRotations++;
            return leftRotate(node);
        }

        // Case 3: Left-Right (LR)
        if (balance > 1 && student.getRegNo() > node.left.student.getRegNo()) {
            lrRotations++;
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Case 4: Right-Left (RL)
        if (balance < -1 && student.getRegNo() < node.right.student.getRegNo()) {
            rlRotations++;
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    /**
     * Searches for a student by registration number in AVL tree.
     */
    public SearchResult search(int regNo) {
        long start = System.nanoTime();
        int comparisons = 0;
        AVLNode current = root;

        while (current != null) {
            comparisons++;
            if (regNo == current.student.getRegNo()) {
                long duration = System.nanoTime() - start;
                return new SearchResult(current.student, true, comparisons, duration);
            } else if (regNo < current.student.getRegNo()) {
                current = current.left;
            } else {
                current = current.right;
            }
        }

        long duration = System.nanoTime() - start;
        return new SearchResult(null, false, comparisons, duration);
    }

    public int getHeight() {
        return height(root);
    }

    public List<Student> inorderTraversal() {
        List<Student> list = new ArrayList<>();
        inorderRec(root, list);
        return list;
    }

    private void inorderRec(AVLNode node, List<Student> list) {
        if (node != null) {
            inorderRec(node.left, list);
            list.add(node.student);
            inorderRec(node.right, list);
        }
    }

    public int getSize() {
        return size;
    }

    public long getTotalInsertionComparisons() {
        return totalInsertionComparisons;
    }

    public int getTotalRotations() {
        return llRotations + rrRotations + lrRotations + rlRotations;
    }

    public int getLlRotations() { return llRotations; }
    public int getRrRotations() { return rrRotations; }
    public int getLrRotations() { return lrRotations; }
    public int getRlRotations() { return rlRotations; }
}
